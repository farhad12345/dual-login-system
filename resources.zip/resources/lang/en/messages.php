<?php
return [
    'add_user' => 'Add User',
    'edit_user' => 'Edit User',
    'delete_user' => 'Delete User',
    'user_list' => 'User List',
    'user_details' => 'User Details',
    'user_name' => 'User Name',
    'email' => 'Email',
    'password' => 'Password',
    'confirm_password' => 'Confirm Password',
    'role' => 'Role',
    'active' => 'Active',
    'inactive' => 'Inactive',
];

?>
