<?php
return [
    'add_user' => 'إضافة مستخدم',
    'edit_user' => 'تعديل مستخدم',
    'delete_user' => 'حذف مستخدم',
    'user_list' => 'قائمة المستخدمين',
    'user_details' => 'تفاصيل المستخدم',
    'user_name' => 'اسم المستخدم',
    'email' => 'البريد الإلكتروني',
    'password' => 'كلمة المرور',
    'confirm_password' => 'تأكيد كلمة المرور',
    'role' => 'الدور',
    'active' => 'نشط',
    'inactive' => 'غير نشط',
];

?>
